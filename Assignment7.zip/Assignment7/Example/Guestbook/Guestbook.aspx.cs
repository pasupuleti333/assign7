﻿// Code-behind file that defines event handlers for the guestbook.
using System;
using System.Collections.Specialized; // for class ListDictionary

public partial class Guestbook : System.Web.UI.Page
{
   // Submit Button adds a new guestbook entry to the database,
   // clears the form and displays the updated list of guestbook entries
   protected void submitButton_Click( object sender, EventArgs e )
   {
        // execute an INSERT  statement to add a new entry to the      
        // Messages table in the Guestbook Access Data Source
        GuestbookAccessDataSource.InsertCommand = 
            "INSERT INTO [Messages] (" +

            "[Date]" + ", " +
            "[Name]" + ", " +
            "[Email]" + ", " +
            "[Message]" + // Caution: no , after the last attribute

            ") VALUES (" +

            ToSql(DateTime.Now.ToShortDateString()) +", " +
            ToSql(nameTextBox.Text) + ", " +
            ToSql(emailTextBox.Text) + ", " +
            ToSql(messageTextBox.Text) + // Caution: no , after the last value

            ")";

        GuestbookAccessDataSource.Insert();

        // clear the TextBoxes
        clearTextBoxes();

      // update the GridView with the new database table contents
      messagesGridView.DataBind();
   } // submitButton_Click

    // format a string value for SQL
    private string ToSql(string stringValue)
    {
        return "'" + stringValue.Replace("'", "''") + "'";
    }

    // clear the TextBoxes
    private void clearTextBoxes()
    {
        nameTextBox.Text = String.Empty;
        emailTextBox.Text = String.Empty;
        messageTextBox.Text = String.Empty;
    }

    // Clear Button clears the Web Form's TextBoxes
    protected void clearButton_Click( object sender, EventArgs e )
   {
        clearTextBoxes();
   } // clearButton_Click

    protected void AccessDataSource1_Selecting(object sender, System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs e)
    {

    }
} // end class Guestbook
